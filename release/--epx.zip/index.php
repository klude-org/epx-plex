<?php
if(!\is_file($f = __DIR__.'/pkg~klude-org~epx-plex/lib/.librarian.php')){
    if(!($c = \file_get_contents("https://raw.githubusercontent.com/klude-org/epx-plex/main/lib/.librarian.php"))){
        throw new \Exception("Failed: Unable to download latest interface");
    }
    \is_dir($d = \dirname($f)) OR \mkdir($d, 0777, true);
    \file_put_contents($f, $c);
}
require $f;
 